/* strformat.c --- 
 * 
 * Filename: strformat.c
 * Description: 字符串操作
 * Author: magc
 * Maintainer: 
 * Created: 一  8月 20 22:56:36 2012 (+0800)
 * Version: 
 * Last-Updated: 六  8月 25 10:33:07 2012 (+0800)
 *           By: magc
 *     Update #: 33
 * URL: 
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 此代码仅为体验Cunit而临时撰写。
 * 
 * 
 */

/* Change Log:
 * 
 * 
 */

/* Code: */
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include "strformat.h"


/**************************************************************************
函数名称：字符串相加
功能描述：
输入参数：
返   回：
**************************************************************************/
string add_str(string word1 ,string word2){
    return (strcat(word1, word2));
}

/**************************************************************************
函数名称：将字符串转换成大写格式
功能描述：
输入参数：
返   回：
**************************************************************************/
string to_Upper(string word){
    int i;
    for(i = 0;word[i] !='\0' ;i++){
        if(word[i]<'z' && word[i]>'a'){
            word[i] -= 32;
        }
    }
    return word;
    
}

/**************************************************************************
函数名称：字符串长度
功能描述：
输入参数：
返   回：
**************************************************************************/
int string_lenth(string word){
    int i;
    for(i = 0 ;word[i] != '\0';i++){
        
    }
    return i;
}

/* strformat.c ends here */
